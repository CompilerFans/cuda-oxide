/*
 * SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

//! Loading CUDA modules from embedded device artifact bundles.

use crate::{CudaContext, CudaModule, DriverError};
pub use cuda_bindings::{CUDA_DRIVER_BACKEND, CudaDriverBackend};
use oxide_artifacts::ArtifactError;
pub use oxide_artifacts::{
    ArtifactCompileOptions, ArtifactDebugPolicy, ArtifactPayloadKind,
    COMPILE_OPTIONS_TARGET_MARKER, OwnedArtifactBundle,
};
use std::fmt;
use std::path::{Path, PathBuf};
use std::sync::Arc;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EmbeddedModule {
    bundle: OwnedArtifactBundle,
}

impl EmbeddedModule {
    pub fn new(bundle: OwnedArtifactBundle) -> Option<Self> {
        loadable_payload(&bundle)
            .is_some()
            .then_some(Self { bundle })
    }

    pub fn name(&self) -> &str {
        &self.bundle.name
    }

    pub fn target(&self) -> &str {
        &self.bundle.target
    }

    pub fn bundle(&self) -> &OwnedArtifactBundle {
        &self.bundle
    }

    pub fn payload(&self, kind: ArtifactPayloadKind) -> Option<&[u8]> {
        self.bundle.payload(kind)
    }

    pub fn load(&self, ctx: &Arc<CudaContext>) -> Result<Arc<CudaModule>, EmbeddedModuleError> {
        let image =
            loadable_payload(&self.bundle).expect("EmbeddedModule always has a loadable payload");
        ctx.load_module_from_image(image)
            .map_err(EmbeddedModuleError::Driver)
    }
}

pub fn artifact_bundles_from_current_exe() -> Result<Vec<OwnedArtifactBundle>, EmbeddedModuleError>
{
    let path =
        std::env::current_exe().map_err(|source| EmbeddedModuleError::CurrentExe { source })?;
    artifact_bundles_from_binary_path(path)
}

pub fn artifact_bundles_from_binary_path(
    path: impl AsRef<Path>,
) -> Result<Vec<OwnedArtifactBundle>, EmbeddedModuleError> {
    let path = path.as_ref();
    let bytes = std::fs::read(path).map_err(|source| EmbeddedModuleError::Io {
        path: path.to_path_buf(),
        source,
    })?;
    oxide_artifacts::read_artifact_bundles_from_object_bytes(&bytes)
        .map_err(EmbeddedModuleError::Artifacts)
}

pub fn embedded_modules_from_current_exe() -> Result<Vec<EmbeddedModule>, EmbeddedModuleError> {
    Ok(artifact_bundles_from_current_exe()?
        .into_iter()
        .filter_map(EmbeddedModule::new)
        .collect())
}

pub fn load_embedded_module(
    ctx: &Arc<CudaContext>,
    name: &str,
) -> Result<Arc<CudaModule>, EmbeddedModuleError> {
    let module = named_embedded_module(artifact_bundles_from_current_exe()?, name)?;
    module.load(ctx)
}

fn named_embedded_module(
    bundles: impl IntoIterator<Item = OwnedArtifactBundle>,
    name: &str,
) -> Result<EmbeddedModule, EmbeddedModuleError> {
    let bundle = bundles
        .into_iter()
        .find(|bundle| bundle.name == name)
        .ok_or_else(|| EmbeddedModuleError::ModuleNotFound {
            name: name.to_string(),
        })?;
    EmbeddedModule::new(bundle).ok_or_else(|| EmbeddedModuleError::UnsupportedPayload {
        name: name.to_string(),
    })
}

pub fn load_first_embedded_module(
    ctx: &Arc<CudaContext>,
) -> Result<Arc<CudaModule>, EmbeddedModuleError> {
    let module = embedded_modules_from_current_exe()?
        .into_iter()
        .next()
        .ok_or(EmbeddedModuleError::NoModules)?;
    module.load(ctx)
}

fn loadable_payload(bundle: &OwnedArtifactBundle) -> Option<&[u8]> {
    loadable_payload_for_backend(bundle, CUDA_DRIVER_BACKEND)
}

/// Selects the direct module image supported by the driver used to build
/// `cuda-core`.
#[doc(hidden)]
pub fn directly_loadable_payload(bundle: &OwnedArtifactBundle) -> Option<&[u8]> {
    loadable_payload(bundle)
}

fn loadable_payload_for_backend(
    bundle: &OwnedArtifactBundle,
    backend: CudaDriverBackend,
) -> Option<&[u8]> {
    match backend {
        CudaDriverBackend::NativeCuda => bundle
            .payload(ArtifactPayloadKind::Cubin)
            .or_else(|| bundle.payload(ArtifactPayloadKind::Ptx)),
        CudaDriverBackend::MacaCuBridge => bundle.payload(ArtifactPayloadKind::MacaDeviceBinary),
    }
}

#[derive(Debug)]
pub enum EmbeddedModuleError {
    CurrentExe {
        source: std::io::Error,
    },
    Io {
        path: PathBuf,
        source: std::io::Error,
    },
    Artifacts(ArtifactError),
    ModuleNotFound {
        name: String,
    },
    UnsupportedPayload {
        name: String,
    },
    NoModules,
    Driver(DriverError),
}

impl fmt::Display for EmbeddedModuleError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::CurrentExe { source } => {
                write!(f, "failed to resolve the current executable: {source}")
            }
            Self::Io { path, source } => write!(f, "failed to read {}: {source}", path.display()),
            Self::Artifacts(error) => write!(f, "failed to read embedded artifacts: {error}"),
            Self::ModuleNotFound { name } => {
                write!(f, "embedded CUDA module '{name}' was not found")
            }
            Self::UnsupportedPayload { name } => {
                write!(f, "embedded CUDA module '{name}' has no supported payload")
            }
            Self::NoModules => f.write_str("no embedded CUDA modules were found"),
            Self::Driver(error) => write!(f, "failed to load embedded CUDA module: {error}"),
        }
    }
}

impl std::error::Error for EmbeddedModuleError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::CurrentExe { source } | Self::Io { source, .. } => Some(source),
            Self::Artifacts(error) => Some(error),
            Self::Driver(error) => Some(error),
            Self::ModuleNotFound { .. } | Self::UnsupportedPayload { .. } | Self::NoModules => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxide_artifacts::{
        ArtifactBundleSpec, ArtifactPayloadSpec, OwnedArtifactPayload, build_artifact_blob,
        build_host_object_for_target,
    };

    #[test]
    fn embedded_module_filters_unloadable_bundles() {
        let bundle = OwnedArtifactBundle {
            name: "demo".to_string(),
            target: "sm_90".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: Vec::new(),
            entries: Vec::new(),
        };

        assert!(EmbeddedModule::new(bundle).is_none());
    }

    #[test]
    fn embedded_module_accepts_ptx_only_with_native_cuda() {
        let bundle = OwnedArtifactBundle {
            name: "demo".to_string(),
            target: "sm_90".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: vec![OwnedArtifactPayload {
                kind: ArtifactPayloadKind::Ptx,
                name: "demo.ptx".to_string(),
                bytes: b"ptx".to_vec(),
            }],
            entries: Vec::new(),
        };

        let module = EmbeddedModule::new(bundle);
        assert_eq!(
            module.is_some(),
            CUDA_DRIVER_BACKEND == CudaDriverBackend::NativeCuda
        );
    }

    #[test]
    fn embedded_module_accepts_cubin_only_with_native_cuda() {
        let bundle = OwnedArtifactBundle {
            name: "demo".to_string(),
            target: "sm_90".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: vec![OwnedArtifactPayload {
                kind: ArtifactPayloadKind::Cubin,
                name: "demo.cubin".to_string(),
                bytes: b"cubin".to_vec(),
            }],
            entries: Vec::new(),
        };

        let module = EmbeddedModule::new(bundle);
        assert_eq!(
            module.is_some(),
            CUDA_DRIVER_BACKEND == CudaDriverBackend::NativeCuda
        );
    }

    #[test]
    fn embedded_module_accepts_maca_binary_only_with_cu_bridge() {
        let bundle = OwnedArtifactBundle {
            name: "demo".to_string(),
            target: "xcore1000".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: vec![OwnedArtifactPayload {
                kind: ArtifactPayloadKind::MacaDeviceBinary,
                name: "demo.devbin".to_string(),
                bytes: b"\x7fELFmaca".to_vec(),
            }],
            entries: Vec::new(),
        };

        let module = EmbeddedModule::new(bundle);
        assert_eq!(
            module.is_some(),
            CUDA_DRIVER_BACKEND == CudaDriverBackend::MacaCuBridge
        );
    }

    #[test]
    fn mixed_bundle_selection_follows_driver_backend() {
        let bundle = OwnedArtifactBundle {
            name: "mixed".to_string(),
            target: "test-target".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: vec![
                OwnedArtifactPayload {
                    kind: ArtifactPayloadKind::Ptx,
                    name: "mixed.ptx".to_string(),
                    bytes: b"ptx".to_vec(),
                },
                OwnedArtifactPayload {
                    kind: ArtifactPayloadKind::Cubin,
                    name: "mixed.cubin".to_string(),
                    bytes: b"cubin".to_vec(),
                },
                OwnedArtifactPayload {
                    kind: ArtifactPayloadKind::MacaDeviceBinary,
                    name: "mixed.devbin".to_string(),
                    bytes: b"\x7fELFmaca".to_vec(),
                },
            ],
            entries: Vec::new(),
        };

        assert_eq!(
            loadable_payload_for_backend(&bundle, CudaDriverBackend::NativeCuda),
            Some(&b"cubin"[..])
        );
        assert_eq!(
            loadable_payload_for_backend(&bundle, CudaDriverBackend::MacaCuBridge),
            Some(&b"\x7fELFmaca"[..])
        );
    }

    #[test]
    fn named_module_distinguishes_missing_from_unsupported_payload() {
        let unsupported = OwnedArtifactBundle {
            name: "present".to_string(),
            target: "test-target".to_string(),
            compile_options: ArtifactCompileOptions::new(),
            payloads: Vec::new(),
            entries: Vec::new(),
        };

        assert!(matches!(
            named_embedded_module([unsupported], "present"),
            Err(EmbeddedModuleError::UnsupportedPayload { name }) if name == "present"
        ));
        assert!(matches!(
            named_embedded_module(Vec::new(), "missing"),
            Err(EmbeddedModuleError::ModuleNotFound { name }) if name == "missing"
        ));
    }

    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    #[test]
    fn artifact_bundles_from_binary_path_reads_linked_executable() {
        let temp_dir = unique_temp_dir("cuda-core-embedded-artifacts");
        std::fs::create_dir_all(&temp_dir).unwrap();

        let source_path = temp_dir.join("main.rs");
        let object_path = temp_dir.join("artifact.o");
        let exe_path = temp_dir.join("host");

        let blob = build_artifact_blob(&ArtifactBundleSpec::new("linked", "sm_90").with_payload(
            ArtifactPayloadSpec::new(ArtifactPayloadKind::Ptx, "linked.ptx", b"ptx"),
        ))
        .unwrap();
        // Mirror production: the backend always defines a link-anchor
        // symbol in the artifact object. The linked-executable round trip
        // must keep working with that symbol present.
        let anchor = reserved_oxide_symbols::artifact_anchor_symbol("linked", "0.0.0");
        let object =
            build_host_object_for_target(&blob, "x86_64-unknown-linux-gnu", Some(anchor.as_str()))
                .unwrap();
        std::fs::write(&source_path, "fn main() {}\n").unwrap();
        std::fs::write(&object_path, object).unwrap();

        let rustc = std::env::var_os("RUSTC").unwrap_or_else(|| "rustc".into());
        let output = std::process::Command::new(rustc)
            .arg(&source_path)
            .arg("-C")
            .arg(format!("link-arg={}", object_path.display()))
            .arg("-o")
            .arg(&exe_path)
            .output()
            .unwrap();

        if !output.status.success() {
            panic!(
                "failed to link artifact test executable\nstdout:\n{}\nstderr:\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
        }

        let bundles = artifact_bundles_from_binary_path(&exe_path).unwrap();
        assert_eq!(bundles.len(), 1);
        assert_eq!(bundles[0].name, "linked");
        assert_eq!(
            bundles[0].payload(ArtifactPayloadKind::Ptx),
            Some(&b"ptx"[..])
        );

        let _ = std::fs::remove_dir_all(temp_dir);
    }

    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    fn unique_temp_dir(name: &str) -> PathBuf {
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        std::env::temp_dir().join(format!("{name}-{}-{nanos}", std::process::id()))
    }
}
