/*
 * SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

use dialect_mir::{
    attributes::{FieldIndexAttr, MirCastKindAttr, VariantIndexAttr},
    ops::{
        MirAddOp, MirAssertOp, MirAssignOp, MirCallOp, MirCastOp, MirCheckedAddOp, MirCmpOp,
        MirCondBranchOp, MirConstantOp, MirConstructDisjointSliceOp, MirConstructEnumOp,
        MirConstructSliceOp, MirDivOp, MirEnumPayloadOp, MirEqOp, MirExtractFieldOp,
        MirFieldAddrOp, MirFuncOp, MirGeOp, MirGetDiscriminantOp, MirGlobalAllocOp, MirGotoOp,
        MirGtOp, MirLeOp, MirLoadOp, MirLtOp, MirMulOp, MirNeOp, MirNegOp, MirNotOp,
        MirPtrOffsetOp, MirRemOp, MirReturnOp, MirSetDiscriminantOp, MirStoreOp, MirSubOp,
    },
    types::{
        EnumVariant, MirDisjointSliceType, MirEnumType, MirPtrType, MirSliceType, MirTupleType,
        MirUnionType,
    },
};
use pliron::{
    basic_block::BasicBlock,
    builtin::{
        attributes::{IntegerAttr, StringAttr, TypeAttr},
        op_interfaces::OperandSegmentInterface,
        types::{FP32Type, FunctionType, IntegerType, Signedness},
    },
    common_traits::Verify,
    context::Context,
    op::Op,
    operation::Operation,
    opts::mem2reg::{AllocInfo, PromotableOpInterface, PromotableOpKind},
    utils::apint::APInt,
};
use std::num::NonZeroUsize;

#[test]
fn test_mir_control_flow_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let i1_ty = IntegerType::get(&ctx, 1, Signedness::Signless);

    // 1. MirGotoOp
    let target_block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let src_block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let arg_val = src_block.deref(&ctx).get_argument(0);

    let op = Operation::new(
        &mut ctx,
        MirGotoOp::get_concrete_op_info(),
        vec![],
        vec![arg_val],
        vec![target_block],
        0,
    );
    let goto_op = MirGotoOp::new(op);
    assert!(goto_op.verify(&ctx).is_ok(), "Valid Goto");

    let op_bad = Operation::new(
        &mut ctx,
        MirGotoOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![target_block],
        0,
    );
    assert!(
        MirGotoOp::new(op_bad).verify(&ctx).is_err(),
        "Goto missing operand"
    );

    // 2. MirCondBranchOp
    let true_block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let false_block = BasicBlock::new(&mut ctx, None, vec![]);
    let cond_block = BasicBlock::new(&mut ctx, None, vec![i1_ty.into(), i32_ty.into()]);
    let cond_val = cond_block.deref(&ctx).get_argument(0);
    let val = cond_block.deref(&ctx).get_argument(1);

    let (cond_flat, cond_sizes) =
        MirCondBranchOp::compute_segment_sizes(vec![vec![cond_val], vec![val], vec![]]);
    let op_cond = Operation::new(
        &mut ctx,
        MirCondBranchOp::get_concrete_op_info(),
        vec![],
        cond_flat,
        vec![true_block, false_block],
        0,
    );
    MirCondBranchOp::new(op_cond).set_operand_segment_sizes(&ctx, cond_sizes);
    let cond_br = MirCondBranchOp::new(op_cond);
    assert!(cond_br.verify(&ctx).is_ok(), "Valid CondBranch");

    let (cond_bad_flat, cond_bad_sizes) =
        MirCondBranchOp::compute_segment_sizes(vec![vec![cond_val], vec![], vec![]]);
    let op_cond_bad = Operation::new(
        &mut ctx,
        MirCondBranchOp::get_concrete_op_info(),
        vec![],
        cond_bad_flat,
        vec![true_block, false_block],
        0,
    );
    MirCondBranchOp::new(op_cond_bad).set_operand_segment_sizes(&ctx, cond_bad_sizes);
    assert!(
        MirCondBranchOp::new(op_cond_bad).verify(&ctx).is_err(),
        "CondBranch missing operand"
    );

    // 3. MirReturnOp
    let func_ty = FunctionType::get(&ctx, vec![], vec![i32_ty.into()]);
    let func_ty_attr = TypeAttr::new(func_ty.into());

    let func_op_ptr = Operation::new(
        &mut ctx,
        MirFuncOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        1,
    );
    let mir_func = MirFuncOp::new(&mut ctx, func_op_ptr, func_ty_attr);
    let entry_block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let ret_val = entry_block.deref(&ctx).get_argument(0);

    let region = mir_func.get_operation().deref(&ctx).get_region(0);
    entry_block.insert_at_front(region, &ctx);

    let ret_op = Operation::new(
        &mut ctx,
        MirReturnOp::get_concrete_op_info(),
        vec![],
        vec![ret_val],
        vec![],
        0,
    );
    ret_op.insert_at_back(entry_block, &ctx);

    let mir_ret = MirReturnOp::new(ret_op);
    assert!(mir_ret.verify(&ctx).is_ok(), "Valid Return");

    let f32_ty = FP32Type::get(&ctx);
    let f32_block = BasicBlock::new(&mut ctx, None, vec![f32_ty.into()]);
    let f32_val = f32_block.deref(&ctx).get_argument(0);

    let ret_op_bad = Operation::new(
        &mut ctx,
        MirReturnOp::get_concrete_op_info(),
        vec![],
        vec![f32_val],
        vec![],
        0,
    );
    ret_op_bad.insert_at_back(entry_block, &ctx);

    let mir_ret_bad = MirReturnOp::new(ret_op_bad);
    assert!(mir_ret_bad.verify(&ctx).is_err(), "Return type mismatch");

    // 4. MirAssertOp
    let assert_succ = BasicBlock::new(&mut ctx, None, vec![]);

    let (assert_flat, assert_sizes) =
        MirAssertOp::compute_segment_sizes(vec![vec![cond_val], vec![]]);
    let op_assert = Operation::new(
        &mut ctx,
        MirAssertOp::get_concrete_op_info(),
        vec![],
        assert_flat,
        vec![assert_succ],
        0,
    );
    MirAssertOp::new(op_assert).set_operand_segment_sizes(&ctx, assert_sizes);
    let assert_op = MirAssertOp::new(op_assert);
    assert!(assert_op.verify(&ctx).is_ok(), "Valid Assert");

    let (assert_bad_flat, assert_bad_sizes) =
        MirAssertOp::compute_segment_sizes(vec![vec![val], vec![]]);
    let op_assert_bad = Operation::new(
        &mut ctx,
        MirAssertOp::get_concrete_op_info(),
        vec![],
        assert_bad_flat,
        vec![assert_succ],
        0,
    );
    MirAssertOp::new(op_assert_bad).set_operand_segment_sizes(&ctx, assert_bad_sizes);
    assert!(
        MirAssertOp::new(op_assert_bad).verify(&ctx).is_err(),
        "Assert cond type mismatch"
    );
}

#[test]
fn test_mir_load_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), false);

    let block = BasicBlock::new(&mut ctx, None, vec![ptr_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);

    let op = Operation::new(
        &mut ctx,
        MirLoadOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![ptr_val],
        vec![],
        0,
    );
    let mir_load = MirLoadOp::new(op);
    assert!(mir_load.verify(&ctx).is_ok(), "Valid MirLoadOp");

    let block_i32 = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let i32_val = block_i32.deref(&ctx).get_argument(0);

    let op_fail_operand = Operation::new(
        &mut ctx,
        MirLoadOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![i32_val],
        vec![],
        0,
    );
    let mir_load_fail_operand = MirLoadOp::new(op_fail_operand);
    assert!(
        mir_load_fail_operand.verify(&ctx).is_err(),
        "MirLoadOp non-ptr operand"
    );

    let f32_ty = FP32Type::get(&ctx);
    let op_fail_res = Operation::new(
        &mut ctx,
        MirLoadOp::get_concrete_op_info(),
        vec![f32_ty.into()],
        vec![ptr_val],
        vec![],
        0,
    );
    let mir_load_fail_res = MirLoadOp::new(op_fail_res);
    assert!(
        mir_load_fail_res.verify(&ctx).is_err(),
        "MirLoadOp result mismatch"
    );
}

#[test]
fn test_mir_load_volatile_is_not_promotable() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), false);
    let block = BasicBlock::new(&mut ctx, None, vec![ptr_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);

    let op = Operation::new(
        &mut ctx,
        MirLoadOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![ptr_val],
        vec![],
        0,
    );
    let mir_load = MirLoadOp::new(op);
    let alloc_info = AllocInfo {
        ptr: ptr_val,
        ty: i32_ty.into(),
    };

    assert!(!mir_load.is_volatile(&ctx));
    assert!(matches!(
        mir_load.promotion_kind(&ctx, &alloc_info),
        PromotableOpKind::Load
    ));

    mir_load.set_volatile(&mut ctx, true);

    assert!(mir_load.is_volatile(&ctx));
    assert!(matches!(
        mir_load.promotion_kind(&ctx, &alloc_info),
        PromotableOpKind::NonPromotableUse
    ));
}

#[test]
fn test_mir_ptr_offset_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), false);
    let usize_ty = IntegerType::get(&ctx, 64, Signedness::Signless);

    let block = BasicBlock::new(&mut ctx, None, vec![ptr_ty.into(), usize_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);
    let idx_val = block.deref(&ctx).get_argument(1);

    let op = Operation::new(
        &mut ctx,
        MirPtrOffsetOp::get_concrete_op_info(),
        vec![ptr_ty.into()],
        vec![ptr_val, idx_val],
        vec![],
        0,
    );
    let offset_op = MirPtrOffsetOp::new(op);
    assert!(offset_op.verify(&ctx).is_ok(), "Valid MirPtrOffsetOp");
    assert!(
        offset_op.is_inbounds(&ctx),
        "ordinary pointer offsets default to inbounds"
    );
    offset_op.set_inbounds(&mut ctx, false);
    assert!(
        !offset_op.is_inbounds(&ctx),
        "wrapping pointer offsets retain their explicit semantics"
    );

    let block2 = BasicBlock::new(&mut ctx, None, vec![i32_ty.into(), usize_ty.into()]);
    let i32_val = block2.deref(&ctx).get_argument(0);
    let idx_val2 = block2.deref(&ctx).get_argument(1);

    let op_bad_base = Operation::new(
        &mut ctx,
        MirPtrOffsetOp::get_concrete_op_info(),
        vec![ptr_ty.into()],
        vec![i32_val, idx_val2],
        vec![],
        0,
    );
    assert!(MirPtrOffsetOp::new(op_bad_base).verify(&ctx).is_err());

    let f32_ty = FP32Type::get(&ctx);
    let ptr_f32_ty = MirPtrType::get_generic(&mut ctx, f32_ty.into(), false);
    let op_bad_res = Operation::new(
        &mut ctx,
        MirPtrOffsetOp::get_concrete_op_info(),
        vec![ptr_f32_ty.into()],
        vec![ptr_val, idx_val],
        vec![],
        0,
    );
    assert!(MirPtrOffsetOp::new(op_bad_res).verify(&ctx).is_err());
}

#[test]
fn test_mir_extract_field_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let tuple_ty = MirTupleType::get(&mut ctx, vec![i32_ty.into(), i32_ty.into()]);

    let block = BasicBlock::new(&mut ctx, None, vec![tuple_ty.into()]);
    let tuple_val = block.deref(&ctx).get_argument(0);

    let op = Operation::new(
        &mut ctx,
        MirExtractFieldOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![tuple_val],
        vec![],
        0,
    );
    let extract_op = MirExtractFieldOp::new(op);
    extract_op.set_attr_index(&ctx, dialect_mir::attributes::FieldIndexAttr(0));
    assert!(extract_op.verify(&ctx).is_ok(), "Valid Tuple Extract");

    let op_oob = Operation::new(
        &mut ctx,
        MirExtractFieldOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![tuple_val],
        vec![],
        0,
    );
    let extract_op_oob = MirExtractFieldOp::new(op_oob);
    extract_op_oob.set_attr_index(&ctx, dialect_mir::attributes::FieldIndexAttr(2));
    assert!(extract_op_oob.verify(&ctx).is_err(), "OOB Index");

    let union_ty = MirUnionType::get(
        &mut ctx,
        "Bits".into(),
        vec!["word".into(), "alias".into()],
        vec![i32_ty.into(), i32_ty.into()],
        4,
        4,
    );
    let union_block = BasicBlock::new(&mut ctx, None, vec![union_ty.into()]);
    let union_val = union_block.deref(&ctx).get_argument(0);
    let union_extract = Operation::new(
        &mut ctx,
        MirExtractFieldOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![union_val],
        vec![],
        0,
    );
    let union_extract = MirExtractFieldOp::new(union_extract);
    union_extract.set_attr_index(&ctx, dialect_mir::attributes::FieldIndexAttr(1));
    assert!(union_extract.verify(&ctx).is_ok(), "Valid union extract");
}

#[test]
fn test_mir_construct_disjoint_slice_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let f32_ty = FP32Type::get(&ctx);
    let usize_ty = IntegerType::get(&ctx, 64, Signedness::Unsigned);
    let width_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);
    let f32_ptr_ty = MirPtrType::get_generic(&mut ctx, f32_ty.into(), true);
    let plain_ty = MirDisjointSliceType::get(&mut ctx, f32_ty.into());
    let width_ty_handle: pliron::r#type::TypeHandle = width_ty.into();
    let row_width_ty =
        MirDisjointSliceType::get_with_space(&mut ctx, f32_ty.into(), vec![width_ty_handle]);

    let block = BasicBlock::new(
        &mut ctx,
        None,
        vec![f32_ptr_ty.into(), usize_ty.into(), width_ty.into()],
    );
    let ptr_val = block.deref(&ctx).get_argument(0);
    let len_val = block.deref(&ctx).get_argument(1);
    let width_val = block.deref(&ctx).get_argument(2);

    // Valid: an index space with no runtime layout takes two operands.
    let op = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![plain_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op).verify(&ctx).is_ok(),
        "Valid space-free disjoint slice construction"
    );

    // Valid: a runtime row width takes a third operand.
    let op_width = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![row_width_ty.into()],
        vec![ptr_val, len_val, width_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op_width)
            .verify(&ctx)
            .is_ok(),
        "Valid row-width disjoint slice construction"
    );

    // Invalid: the row width is missing, so the slice would carry whatever
    // slot 2 held.
    let op_missing_width = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![row_width_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op_missing_width)
            .verify(&ctx)
            .is_err(),
        "Missing index-space operand"
    );

    // Invalid: a space-free slice given a third operand.
    let op_extra = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![plain_ty.into()],
        vec![ptr_val, len_val, width_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op_extra)
            .verify(&ctx)
            .is_err(),
        "Index-space operand for a space-free slice"
    );

    // Invalid: the row width operand has the wrong width, which would write a
    // 64-bit value into the 32-bit row width slot.
    let op_wrong_width_ty = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![row_width_ty.into()],
        vec![ptr_val, len_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op_wrong_width_ty)
            .verify(&ctx)
            .is_err(),
        "Index-space operand type mismatch"
    );

    // Invalid: result is a plain slice, which `mir.construct_slice` owns.
    let plain_slice_ty = MirSliceType::get(&mut ctx, f32_ty.into());
    let op_bad_res = Operation::new(
        &mut ctx,
        MirConstructDisjointSliceOp::get_concrete_op_info(),
        vec![plain_slice_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructDisjointSliceOp::new(op_bad_res)
            .verify(&ctx)
            .is_err(),
        "Result must be a disjoint slice type"
    );
}

#[test]
fn test_mir_construct_slice_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let u8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let usize_ty = IntegerType::get(&ctx, 64, Signedness::Unsigned);
    let u8_ptr_ty = MirPtrType::get_generic(&mut ctx, u8_ty.into(), false);
    let u8_slice_ty = MirSliceType::get(&mut ctx, u8_ty.into());
    let i32_slice_ty = MirSliceType::get(&mut ctx, i32_ty.into());

    let block = BasicBlock::new(&mut ctx, None, vec![u8_ptr_ty.into(), usize_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);
    let len_val = block.deref(&ctx).get_argument(1);

    // Valid: (ptr to u8, usize len) -> slice of u8
    let op = Operation::new(
        &mut ctx,
        MirConstructSliceOp::get_concrete_op_info(),
        vec![u8_slice_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructSliceOp::new(op).verify(&ctx).is_ok(),
        "Valid slice construction"
    );

    // Invalid: data pointer pointee does not match slice element type
    let op_bad_elem = Operation::new(
        &mut ctx,
        MirConstructSliceOp::get_concrete_op_info(),
        vec![i32_slice_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructSliceOp::new(op_bad_elem).verify(&ctx).is_err(),
        "Pointee/element mismatch"
    );

    // Invalid: operands swapped (length where the pointer should be)
    let op_swapped = Operation::new(
        &mut ctx,
        MirConstructSliceOp::get_concrete_op_info(),
        vec![u8_slice_ty.into()],
        vec![len_val, ptr_val],
        vec![],
        0,
    );
    assert!(
        MirConstructSliceOp::new(op_swapped).verify(&ctx).is_err(),
        "Swapped operands"
    );

    // Invalid: result is not a slice type
    let op_bad_res = Operation::new(
        &mut ctx,
        MirConstructSliceOp::get_concrete_op_info(),
        vec![u8_ptr_ty.into()],
        vec![ptr_val, len_val],
        vec![],
        0,
    );
    assert!(
        MirConstructSliceOp::new(op_bad_res).verify(&ctx).is_err(),
        "Non-slice result type"
    );
}

#[test]
fn test_mir_arithmetic_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into(), i32_ty.into()]);
    let lhs = block.deref(&ctx).get_argument(0);

    let check_bin_op = |opid: (
        fn(pliron::context::Ptr<pliron::operation::Operation>) -> pliron::op::OpObj,
        std::any::TypeId,
    ),
                        name: &str| {
        let mut context = Context::new();
        dialect_mir::register(&mut context);
        let ty = IntegerType::get(&context, 32, Signedness::Signed);
        let blk = BasicBlock::new(&mut context, None, vec![ty.into(), ty.into()]);
        let l = blk.deref(&context).get_argument(0);
        let r = blk.deref(&context).get_argument(1);

        let op = Operation::new(&mut context, opid, vec![ty.into()], vec![l, r], vec![], 0);
        assert!(op.verify(&context).is_ok(), "Valid {}", name);

        let f32_t = FP32Type::get(&context);
        let blk2 = BasicBlock::new(&mut context, None, vec![f32_t.into()]);
        let f32_val = blk2.deref(&context).get_argument(0);

        let op_bad = Operation::new(
            &mut context,
            opid,
            vec![ty.into()],
            vec![l, f32_val],
            vec![],
            0,
        );
        assert!(op_bad.verify(&context).is_err(), "Type mismatch {}", name);
    };

    check_bin_op(MirAddOp::get_concrete_op_info(), "Add");
    check_bin_op(MirSubOp::get_concrete_op_info(), "Sub");
    check_bin_op(MirMulOp::get_concrete_op_info(), "Mul");
    check_bin_op(MirDivOp::get_concrete_op_info(), "Div");
    check_bin_op(MirRemOp::get_concrete_op_info(), "Rem");

    let op_neg = Operation::new(
        &mut ctx,
        MirNegOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![lhs],
        vec![],
        0,
    );
    assert!(op_neg.verify(&ctx).is_ok(), "Valid Neg");

    let f32_ty = FP32Type::get(&ctx);
    let op_neg_bad = Operation::new(
        &mut ctx,
        MirNegOp::get_concrete_op_info(),
        vec![f32_ty.into()],
        vec![lhs],
        vec![],
        0,
    );
    assert!(op_neg_bad.verify(&ctx).is_err(), "Neg type mismatch");

    let op_not = Operation::new(
        &mut ctx,
        MirNotOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![lhs],
        vec![],
        0,
    );
    assert!(op_not.verify(&ctx).is_ok(), "Valid Not");
}

#[test]
fn test_mir_misc_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let i64_ty = IntegerType::get(&ctx, 64, Signedness::Signed);
    let i1_ty = IntegerType::get(&ctx, 1, Signedness::Signless);

    // 1. MirConstantOp
    let i32_signless = IntegerType::get(&ctx, 32, Signedness::Signless);
    let width = NonZeroUsize::new(32).unwrap();
    let apint = APInt::from_u32(42, width);
    let int_attr = IntegerAttr::new(i32_signless, apint);

    let const_op_ptr = Operation::new(
        &mut ctx,
        MirConstantOp::get_concrete_op_info(),
        vec![i32_signless.into()],
        vec![],
        vec![],
        0,
    );
    let const_op = MirConstantOp::new(const_op_ptr);
    const_op.set_attr_value(&ctx, int_attr);
    assert!(const_op.verify(&ctx).is_ok(), "Valid Constant");

    // Mismatch type
    let i64_signless = IntegerType::get(&ctx, 64, Signedness::Signless);
    let i64_width = NonZeroUsize::new(64).unwrap();
    let i64_attr = IntegerAttr::new(i64_signless, APInt::from_u64(42, i64_width));
    const_op.set_attr_value(&ctx, i64_attr);
    assert!(const_op.verify(&ctx).is_err(), "Constant type mismatch");

    // 2. MirCastOp
    let block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let arg = block.deref(&ctx).get_argument(0);

    let cast_op = Operation::new(
        &mut ctx,
        MirCastOp::get_concrete_op_info(),
        vec![i64_ty.into()],
        vec![arg],
        vec![],
        0,
    );
    MirCastOp::new(cast_op).set_attr_cast_kind(&ctx, MirCastKindAttr::IntToInt);
    assert!(MirCastOp::new(cast_op).verify(&ctx).is_ok(), "Valid Cast");

    // 3. MirCheckedAddOp
    let tuple_ty = MirTupleType::get(&mut ctx, vec![i32_ty.into(), i1_ty.into()]);
    let block2 = BasicBlock::new(&mut ctx, None, vec![i32_ty.into(), i32_ty.into()]);
    let lhs = block2.deref(&ctx).get_argument(0);
    let rhs = block2.deref(&ctx).get_argument(1);

    let checked_add = Operation::new(
        &mut ctx,
        MirCheckedAddOp::get_concrete_op_info(),
        vec![tuple_ty.into()],
        vec![lhs, rhs],
        vec![],
        0,
    );
    assert!(
        MirCheckedAddOp::new(checked_add).verify(&ctx).is_ok(),
        "Valid CheckedAdd"
    );

    // Invalid result type (not tuple)
    let checked_add_bad = Operation::new(
        &mut ctx,
        MirCheckedAddOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![lhs, rhs],
        vec![],
        0,
    );
    assert!(
        MirCheckedAddOp::new(checked_add_bad).verify(&ctx).is_err(),
        "CheckedAdd bad result"
    );
}

#[test]
fn test_mir_comparison_verify() {
    let check_cmp = |opid: (
        fn(pliron::context::Ptr<pliron::operation::Operation>) -> pliron::op::OpObj,
        std::any::TypeId,
    ),
                     name: &str| {
        let mut context = Context::new();
        dialect_mir::register(&mut context);
        let ty = IntegerType::get(&context, 32, Signedness::Signed);
        let res_ty = IntegerType::get(&context, 1, Signedness::Signless);
        let blk = BasicBlock::new(&mut context, None, vec![ty.into(), ty.into()]);
        let l = blk.deref(&context).get_argument(0);
        let r = blk.deref(&context).get_argument(1);

        let op = Operation::new(
            &mut context,
            opid,
            vec![res_ty.into()],
            vec![l, r],
            vec![],
            0,
        );
        assert!(op.verify(&context).is_ok(), "Valid {}", name);

        // Invalid operand types
        let f32_ty = FP32Type::get(&context);
        let blk2 = BasicBlock::new(&mut context, None, vec![f32_ty.into()]);
        let f32_val = blk2.deref(&context).get_argument(0);
        let op_bad = Operation::new(
            &mut context,
            opid,
            vec![res_ty.into()],
            vec![l, f32_val],
            vec![],
            0,
        );
        assert!(op_bad.verify(&context).is_err(), "Type mismatch {}", name);

        // Invalid result type
        let op_bad_res = Operation::new(
            &mut context,
            opid,
            vec![ty.into()], // i32 result instead of i1
            vec![l, r],
            vec![],
            0,
        );
        assert!(
            op_bad_res.verify(&context).is_err(),
            "Result type mismatch {}",
            name
        );
    };

    check_cmp(MirEqOp::get_concrete_op_info(), "Eq");
    check_cmp(MirNeOp::get_concrete_op_info(), "Ne");
    check_cmp(MirLtOp::get_concrete_op_info(), "Lt");
    check_cmp(MirLeOp::get_concrete_op_info(), "Le");
    check_cmp(MirGtOp::get_concrete_op_info(), "Gt");
    check_cmp(MirGeOp::get_concrete_op_info(), "Ge");

    let mut context = Context::new();
    dialect_mir::register(&mut context);
    let i8_ty = IntegerType::get(&context, 8, Signedness::Signed);
    let i32_ty = IntegerType::get(&context, 32, Signedness::Signed);
    let unit = |name: &str| EnumVariant::unit(name.to_string());
    let ordering_ty = MirEnumType::get(
        &mut context,
        "Ordering".to_string(),
        i8_ty.into(),
        vec![255, 0, 1],
        vec![unit("Less"), unit("Equal"), unit("Greater")],
    );
    let blk = BasicBlock::new(&mut context, None, vec![i32_ty.into(), i32_ty.into()]);
    let lhs = blk.deref(&context).get_argument(0);
    let rhs = blk.deref(&context).get_argument(1);
    let two_variant_ty = MirEnumType::get(
        &mut context,
        "Two".to_string(),
        i8_ty.into(),
        vec![0, 1],
        vec![unit("A"), unit("B")],
    );
    // Payload variants disqualify the Ordering shape.
    let payload_ty = MirEnumType::get(
        &mut context,
        "ThreeWithPayload".to_string(),
        i8_ty.into(),
        vec![0, 1, 2],
        vec![
            unit("A"),
            EnumVariant::new("B".to_string(), vec![i32_ty.into()]),
            unit("C"),
        ],
    );
    let mut check_cmp_result = |result_ty, valid| {
        let op = Operation::new(
            &mut context,
            MirCmpOp::get_concrete_op_info(),
            vec![result_ty],
            vec![lhs, rhs],
            vec![],
            0,
        );
        assert_eq!(op.verify(&context).is_ok(), valid);
    };
    check_cmp_result(ordering_ty.into(), true);
    check_cmp_result(i32_ty.into(), false);
    check_cmp_result(two_variant_ty.into(), false);
    check_cmp_result(payload_ty.into(), false);

    // Float operands are rejected: rustc never emits BinOp::Cmp on floats.
    let f32_ty = FP32Type::get(&context);
    let fblk = BasicBlock::new(&mut context, None, vec![f32_ty.into(), f32_ty.into()]);
    let flhs = fblk.deref(&context).get_argument(0);
    let frhs = fblk.deref(&context).get_argument(1);
    let float_cmp = Operation::new(
        &mut context,
        MirCmpOp::get_concrete_op_info(),
        vec![ordering_ty.into()],
        vec![flhs, frhs],
        vec![],
        0,
    );
    assert!(
        float_cmp.verify(&context).is_err(),
        "float mir.cmp must be rejected"
    );
}

#[test]
fn test_mir_func_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let func_ty = FunctionType::get(&ctx, vec![i32_ty.into()], vec![]);
    let func_ty_attr = TypeAttr::new(func_ty.into());

    // Valid Function
    let op_ptr = Operation::new(
        &mut ctx,
        MirFuncOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        1,
    );
    let mir_func = MirFuncOp::new(&mut ctx, op_ptr, func_ty_attr.clone());

    // Add entry block with correct argument
    let region = mir_func.get_operation().deref(&ctx).get_region(0);
    let entry_block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    entry_block.insert_at_front(region, &ctx);

    assert!(mir_func.verify(&ctx).is_ok(), "Valid MirFuncOp");

    // Invalid: Argument count mismatch
    let op_ptr2 = Operation::new(
        &mut ctx,
        MirFuncOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        1,
    );
    let mir_func2 = MirFuncOp::new(&mut ctx, op_ptr2, func_ty_attr.clone());
    let region2 = mir_func2.get_operation().deref(&ctx).get_region(0);
    // Block with 0 args
    let entry_block2 = BasicBlock::new(&mut ctx, None, vec![]);
    entry_block2.insert_at_front(region2, &ctx);

    assert!(
        mir_func2.verify(&ctx).is_err(),
        "MirFuncOp argument count mismatch"
    );

    // Invalid: Argument type mismatch
    let op_ptr3 = Operation::new(
        &mut ctx,
        MirFuncOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        1,
    );
    let mir_func3 = MirFuncOp::new(&mut ctx, op_ptr3, func_ty_attr);
    let region3 = mir_func3.get_operation().deref(&ctx).get_region(0);
    let f32_ty = FP32Type::get(&ctx);
    let entry_block3 = BasicBlock::new(&mut ctx, None, vec![f32_ty.into()]);
    entry_block3.insert_at_front(region3, &ctx);

    assert!(
        mir_func3.verify(&ctx).is_err(),
        "MirFuncOp argument type mismatch"
    );
}

#[test]
fn test_mir_assign_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let val = block.deref(&ctx).get_argument(0);

    let op = Operation::new(
        &mut ctx,
        MirAssignOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![val],
        vec![],
        0,
    );
    assert!(
        MirAssignOp::new(op).verify(&ctx).is_ok(),
        "Valid MirAssignOp"
    );

    let f32_ty = FP32Type::get(&ctx);
    let op_bad = Operation::new(
        &mut ctx,
        MirAssignOp::get_concrete_op_info(),
        vec![f32_ty.into()],
        vec![val],
        vec![],
        0,
    );
    assert!(
        MirAssignOp::new(op_bad).verify(&ctx).is_err(),
        "MirAssignOp type mismatch"
    );
}

#[test]
fn test_mir_call_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let op = Operation::new(
        &mut ctx,
        MirCallOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        0,
    );
    let call_op = MirCallOp::new(op);

    // Missing attribute
    assert!(call_op.verify(&ctx).is_err(), "MirCallOp missing attribute");

    // With attribute
    let name = StringAttr::new("my_func".to_string());
    call_op.set_attr_callee(&ctx, name);
    assert!(call_op.verify(&ctx).is_ok(), "Valid MirCallOp");
}

#[test]
fn test_mir_store_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), false);
    let block = BasicBlock::new(&mut ctx, None, vec![ptr_ty.into(), i32_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);
    let val = block.deref(&ctx).get_argument(1);

    let op = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![ptr_val, val],
        vec![],
        0,
    );
    assert!(MirStoreOp::new(op).verify(&ctx).is_ok(), "Valid MirStoreOp");

    // Invalid: store to non-ptr
    let op_bad_ptr = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![val, val],
        vec![],
        0,
    );
    assert!(
        MirStoreOp::new(op_bad_ptr).verify(&ctx).is_err(),
        "MirStoreOp non-ptr dest"
    );

    // Invalid: type mismatch
    let f32_ty = FP32Type::get(&ctx);
    let block2 = BasicBlock::new(&mut ctx, None, vec![f32_ty.into()]);
    let f32_val = block2.deref(&ctx).get_argument(0);
    let op_bad_type = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![ptr_val, f32_val],
        vec![],
        0,
    );
    assert!(
        MirStoreOp::new(op_bad_type).verify(&ctx).is_err(),
        "MirStoreOp type mismatch"
    );
}

#[test]
fn test_mir_store_volatile_is_not_promotable() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), false);
    let block = BasicBlock::new(&mut ctx, None, vec![ptr_ty.into(), i32_ty.into()]);
    let ptr_val = block.deref(&ctx).get_argument(0);
    let val = block.deref(&ctx).get_argument(1);

    let op = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![ptr_val, val],
        vec![],
        0,
    );
    let mir_store = MirStoreOp::new(op);
    let alloc_info = AllocInfo {
        ptr: ptr_val,
        ty: i32_ty.into(),
    };

    assert!(!mir_store.is_volatile(&ctx));
    match mir_store.promotion_kind(&ctx, &alloc_info) {
        PromotableOpKind::Store(stored) => assert!(stored == val),
        _ => panic!("non-volatile store should be promotable"),
    }

    mir_store.set_volatile(&mut ctx, true);

    assert!(mir_store.is_volatile(&ctx));
    assert!(matches!(
        mir_store.promotion_kind(&ctx, &alloc_info),
        PromotableOpKind::NonPromotableUse
    ));
}

#[test]
fn test_mir_global_alloc_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let f32_ty = FP32Type::get(&ctx);

    // Helper: build a MirGlobalAllocOp whose result pointer is in `ptr_ty`
    // address space, with valid attributes.
    let build = |ctx: &mut Context, ptr_ty: pliron::r#type::TypedHandle<MirPtrType>| {
        let op = Operation::new(
            ctx,
            MirGlobalAllocOp::get_concrete_op_info(),
            vec![ptr_ty.into()],
            vec![],
            vec![],
            0,
        );
        let alloc = MirGlobalAllocOp::new(op);
        alloc.set_attr_global_type(ctx, TypeAttr::new(f32_ty.into()));
        alloc.set_attr_global_key(ctx, StringAttr::new("k".to_string()));
        alloc
    };

    // Global memory (addrspace 1) — the original allowed space.
    let ptr_global = MirPtrType::get_global(&mut ctx, f32_ty.into(), true);
    assert!(
        build(&mut ctx, ptr_global).verify(&ctx).is_ok(),
        "global addrspace accepted"
    );

    // Constant memory (addrspace 4) — added for `#[constant]` support.
    let ptr_const = MirPtrType::get_constant(&mut ctx, f32_ty.into(), true);
    assert!(
        build(&mut ctx, ptr_const).verify(&ctx).is_ok(),
        "constant addrspace accepted"
    );

    // Shared memory (addrspace 3) — must be rejected.
    let ptr_shared = MirPtrType::get_shared(&mut ctx, f32_ty.into(), true);
    assert!(
        build(&mut ctx, ptr_shared).verify(&ctx).is_err(),
        "shared addrspace rejected"
    );

    // Missing required attributes.
    let no_attrs = Operation::new(
        &mut ctx,
        MirGlobalAllocOp::get_concrete_op_info(),
        vec![ptr_global.into()],
        vec![],
        vec![],
        0,
    );
    assert!(
        MirGlobalAllocOp::new(no_attrs).verify(&ctx).is_err(),
        "missing attributes rejected"
    );
}

#[test]
fn test_mir_set_discriminant_verify() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let i8_ty = IntegerType::get(&ctx, 8, Signedness::Signed);
    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Signed);
    let unit = |name: &str| EnumVariant::unit(name.to_string());

    let enum_ty = MirEnumType::get(
        &mut ctx,
        "DeviceState".to_string(),
        i8_ty.into(),
        vec![0, 1],
        vec![
            unit("Empty"),
            EnumVariant::new("Full".to_string(), vec![i32_ty.into()]),
        ],
    );

    let enum_ptr_ty = MirPtrType::get_generic(&mut ctx, enum_ty.into(), true);
    let blk = BasicBlock::new(&mut ctx, None, vec![enum_ptr_ty.into(), i8_ty.into()]);
    let enum_ptr = blk.deref(&ctx).get_argument(0);
    let discr_val = blk.deref(&ctx).get_argument(1);

    // Malformed IR must be diagnosed without panicking, regardless of whether
    // the generated operand-count interface happens to run first.
    let op_no_operands = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        0,
    );
    let no_operands = MirSetDiscriminantOp::new(op_no_operands);
    no_operands.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(0));
    assert!(no_operands.verify(&ctx).is_err(), "zero operands rejected");

    let op_extra_operand = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![enum_ptr, discr_val],
        vec![],
        0,
    );
    let extra_operand = MirSetDiscriminantOp::new(op_extra_operand);
    extra_operand.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(0));
    assert!(
        extra_operand.verify(&ctx).is_err(),
        "extra operand rejected"
    );

    // Valid: pointer to enum plus the semantic target variant attribute.
    let op_valid = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![enum_ptr],
        vec![],
        0,
    );
    let valid = MirSetDiscriminantOp::new(op_valid);
    valid.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(1));
    assert!(valid.verify(&ctx).is_ok(), "Valid set_discriminant");

    // Invalid: first operand is not a pointer.
    let op_bad_ptr = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![discr_val],
        vec![],
        0,
    );
    assert!(
        MirSetDiscriminantOp::new(op_bad_ptr).verify(&ctx).is_err(),
        "Non-pointer enum operand rejected"
    );

    // Invalid: SetDiscriminant writes memory and therefore cannot accept an
    // immutable pointer even when the pointee is the right enum.
    let immutable_ptr_ty = MirPtrType::get_generic(&mut ctx, enum_ty.into(), false);
    let immutable_block = BasicBlock::new(&mut ctx, None, vec![immutable_ptr_ty.into()]);
    let immutable_ptr = immutable_block.deref(&ctx).get_argument(0);
    let op_immutable = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![immutable_ptr],
        vec![],
        0,
    );
    let immutable = MirSetDiscriminantOp::new(op_immutable);
    immutable.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(0));
    assert!(
        immutable.verify(&ctx).is_err(),
        "immutable pointer rejected"
    );

    // Invalid: pointer does not point to an enum.
    let i32_ptr_ty = MirPtrType::get_generic(&mut ctx, i32_ty.into(), true);
    let blk_i32 = BasicBlock::new(&mut ctx, None, vec![i32_ptr_ty.into(), i8_ty.into()]);
    let i32_ptr = blk_i32.deref(&ctx).get_argument(0);
    let op_bad_pointee = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![i32_ptr],
        vec![],
        0,
    );
    let bad_pointee = MirSetDiscriminantOp::new(op_bad_pointee);
    bad_pointee.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(0));
    assert!(
        bad_pointee.verify(&ctx).is_err(),
        "Non-enum pointee rejected"
    );

    // Invalid: target attribute is required.
    let op_missing_target = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![enum_ptr],
        vec![],
        0,
    );
    assert!(
        MirSetDiscriminantOp::new(op_missing_target)
            .verify(&ctx)
            .is_err(),
        "Missing target rejected"
    );

    // Invalid: target index is out of bounds.
    let op_oob = Operation::new(
        &mut ctx,
        MirSetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![enum_ptr],
        vec![],
        0,
    );
    let oob = MirSetDiscriminantOp::new(op_oob);
    oob.set_attr_set_discriminant_variant_index(&ctx, VariantIndexAttr(2));
    assert!(oob.verify(&ctx).is_err(), "Out-of-bounds target rejected");
}

#[test]
fn test_mir_enum_ops_malformed_arity_is_diagnostic() {
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);
    let i8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);
    let unit_enum = MirEnumType::get(
        &mut ctx,
        "Unit".into(),
        i8_ty.into(),
        vec![0],
        vec![EnumVariant::unit("Only".into())],
    );
    let payload_enum = MirEnumType::get(
        &mut ctx,
        "Payload".into(),
        i8_ty.into(),
        vec![0],
        vec![EnumVariant::new("Only".into(), vec![i32_ty.into()])],
    );
    let block = BasicBlock::new(&mut ctx, None, vec![unit_enum.into(), payload_enum.into()]);
    let unit_value = block.deref(&ctx).get_argument(0);
    let payload_value = block.deref(&ctx).get_argument(1);

    let construct_no_result = Operation::new(
        &mut ctx,
        MirConstructEnumOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        0,
    );
    let construct_no_result = MirConstructEnumOp::new(construct_no_result);
    construct_no_result.set_attr_construct_enum_variant_index(&ctx, VariantIndexAttr(0));
    assert!(construct_no_result.verify(&ctx).is_err());

    let construct_extra_result = Operation::new(
        &mut ctx,
        MirConstructEnumOp::get_concrete_op_info(),
        vec![unit_enum.into(), unit_enum.into()],
        vec![],
        vec![],
        0,
    );
    let construct_extra_result = MirConstructEnumOp::new(construct_extra_result);
    construct_extra_result.set_attr_construct_enum_variant_index(&ctx, VariantIndexAttr(0));
    assert!(construct_extra_result.verify(&ctx).is_err());

    let get_empty = Operation::new(
        &mut ctx,
        MirGetDiscriminantOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        0,
    );
    assert!(MirGetDiscriminantOp::new(get_empty).verify(&ctx).is_err());
    let get_extra = Operation::new(
        &mut ctx,
        MirGetDiscriminantOp::get_concrete_op_info(),
        vec![i8_ty.into(), i8_ty.into()],
        vec![unit_value, unit_value],
        vec![],
        0,
    );
    assert!(MirGetDiscriminantOp::new(get_extra).verify(&ctx).is_err());

    let payload_empty = Operation::new(
        &mut ctx,
        MirEnumPayloadOp::get_concrete_op_info(),
        vec![],
        vec![],
        vec![],
        0,
    );
    let payload_empty = MirEnumPayloadOp::new(payload_empty);
    payload_empty.set_attr_payload_variant_index(&ctx, VariantIndexAttr(0));
    payload_empty.set_attr_payload_field_index(&ctx, FieldIndexAttr(0));
    assert!(payload_empty.verify(&ctx).is_err());

    let payload_extra = Operation::new(
        &mut ctx,
        MirEnumPayloadOp::get_concrete_op_info(),
        vec![i32_ty.into(), i32_ty.into()],
        vec![payload_value, payload_value],
        vec![],
        0,
    );
    let payload_extra = MirEnumPayloadOp::new(payload_extra);
    payload_extra.set_attr_payload_variant_index(&ctx, VariantIndexAttr(0));
    payload_extra.set_attr_payload_field_index(&ctx, FieldIndexAttr(0));
    assert!(payload_extra.verify(&ctx).is_err());
}

#[test]
fn test_mir_enum_payload_rejects_uninhabited_variant() {
    use dialect_mir::types::{EnumCarrierKind, EnumEncoding, EnumLayoutKind};

    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);
    let i8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);
    let enum_ty = MirEnumType::get_with_encoding(
        &mut ctx,
        "HasImpossibleField".into(),
        i8_ty.into(),
        vec![0, 1],
        vec![
            EnumVariant::unit("Live".into()),
            // An uninhabited variant's unused physical offsets need not fit
            // the object. The verifier must stop them reaching lowering.
            EnumVariant::new_with_layout(
                "Impossible".into(),
                vec![i32_ty.into()],
                vec![64],
                vec![4],
            ),
        ],
        EnumEncoding {
            tag_offset: 0,
            total_size: 1,
            abi_align: 1,
            layout_kind: EnumLayoutKind::Direct,
            carrier_kind: EnumCarrierKind::Integer,
            carrier_width: 8,
            variant_inhabited: vec![1, 0],
            ..EnumEncoding::default()
        },
    );
    assert!(enum_ty.verify(&ctx).is_ok());

    let block = BasicBlock::new(&mut ctx, None, vec![enum_ty.into()]);
    let value = block.deref(&ctx).get_argument(0);
    let op = Operation::new(
        &mut ctx,
        MirEnumPayloadOp::get_concrete_op_info(),
        vec![i32_ty.into()],
        vec![value],
        vec![],
        0,
    );
    let payload = MirEnumPayloadOp::new(op);
    payload.set_attr_payload_variant_index(&ctx, VariantIndexAttr(1));
    payload.set_attr_payload_field_index(&ctx, FieldIndexAttr(0));
    assert!(payload.verify(&ctx).is_err());
}

/// Reachable-but-dead MIR (e.g. the residual arms of `array::try_from_fn`)
/// can name uninhabited variants. The importer must lower such reads and
/// constructions to typed undefs; if it ever emits the real ops again, these
/// verifiers are the loud stop.
#[test]
fn test_uninhabited_enum_construct_and_discriminant_fail_verification() {
    use dialect_mir::types::{EnumCarrierKind, EnumEncoding, EnumLayoutKind};

    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);
    let i8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let i32_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);

    // Constructing an uninhabited variant must fail verification.
    let partial = MirEnumType::get_with_encoding(
        &mut ctx,
        "HasImpossibleVariant".into(),
        i8_ty.into(),
        vec![0, 1],
        vec![
            EnumVariant::unit("Live".into()),
            EnumVariant::new_with_layout(
                "Impossible".into(),
                vec![i32_ty.into()],
                vec![0],
                vec![4],
            ),
        ],
        EnumEncoding {
            tag_offset: 0,
            total_size: 8,
            abi_align: 4,
            layout_kind: EnumLayoutKind::Direct,
            carrier_kind: EnumCarrierKind::Integer,
            carrier_width: 8,
            variant_inhabited: vec![1, 0],
            ..EnumEncoding::default()
        },
    );
    let block = BasicBlock::new(&mut ctx, None, vec![i32_ty.into()]);
    let field = block.deref(&ctx).get_argument(0);
    let construct = Operation::new(
        &mut ctx,
        MirConstructEnumOp::get_concrete_op_info(),
        vec![partial.into()],
        vec![field],
        vec![],
        0,
    );
    let construct = MirConstructEnumOp::new(construct);
    construct.set_attr_construct_enum_variant_index(&ctx, VariantIndexAttr(1));
    assert!(construct.verify(&ctx).is_err());

    // Reading the discriminant of a fully uninhabited enum must fail
    // verification.
    let never = MirEnumType::get_with_encoding(
        &mut ctx,
        "Never".into(),
        i8_ty.into(),
        vec![],
        vec![],
        EnumEncoding {
            tag_offset: 0,
            total_size: 0,
            abi_align: 1,
            layout_kind: EnumLayoutKind::Empty,
            carrier_kind: EnumCarrierKind::None,
            carrier_width: 0,
            variant_inhabited: vec![],
            ..EnumEncoding::default()
        },
    );
    assert!(never.verify(&ctx).is_ok());
    let never_block = BasicBlock::new(&mut ctx, None, vec![never.into()]);
    let never_value = never_block.deref(&ctx).get_argument(0);
    let get_discriminant = Operation::new(
        &mut ctx,
        MirGetDiscriminantOp::get_concrete_op_info(),
        vec![i8_ty.into()],
        vec![never_value],
        vec![],
        0,
    );
    let get_discriminant = MirGetDiscriminantOp::new(get_discriminant);
    assert!(get_discriminant.verify(&ctx).is_err());
}

#[test]
fn test_mir_field_addr_tuple_pointee_verify() {
    // `(u8, u32)` laid out the way rustc actually places it: the u32 field
    // first in memory for alignment, so declaration index 0 (`u8`) lands at
    // byte offset 4 and declaration index 1 (`u32`) lands at byte offset 0.
    // `field_addr`'s `field_index` attribute is a DECLARATION index (it names
    // `.0`/`.1` as written), so this test only passes if the op resolves the
    // field's type through `MirTupleType::get_types()` (declaration order)
    // rather than assuming identity with memory order.
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let u8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let u32_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);

    let tuple_ty = MirTupleType::get_with_layout(
        &mut ctx,
        vec![u8_ty.into(), u32_ty.into()],
        vec![1, 0],
        vec![4, 0],
        8,
        4,
    );

    let tuple_ptr_ty = MirPtrType::get_generic(&mut ctx, tuple_ty.into(), false);
    let blk = BasicBlock::new(&mut ctx, None, vec![tuple_ptr_ty.into()]);
    let tuple_ptr = blk.deref(&ctx).get_argument(0);

    let u8_ptr_ty = MirPtrType::get_generic(&mut ctx, u8_ty.into(), false);
    let op_field0 = Operation::new(
        &mut ctx,
        MirFieldAddrOp::get_concrete_op_info(),
        vec![u8_ptr_ty.into()],
        vec![tuple_ptr],
        vec![],
        0,
    );
    let field0 = MirFieldAddrOp::new(op_field0);
    field0.set_attr_field_index(&ctx, FieldIndexAttr(0));
    assert!(
        field0.verify(&ctx).is_ok(),
        "tuple field 0 (u8) address accepted"
    );

    let u32_ptr_ty = MirPtrType::get_generic(&mut ctx, u32_ty.into(), false);
    let op_field1 = Operation::new(
        &mut ctx,
        MirFieldAddrOp::get_concrete_op_info(),
        vec![u32_ptr_ty.into()],
        vec![tuple_ptr],
        vec![],
        0,
    );
    let field1 = MirFieldAddrOp::new(op_field1);
    field1.set_attr_field_index(&ctx, FieldIndexAttr(1));
    assert!(
        field1.verify(&ctx).is_ok(),
        "tuple field 1 (u32) address accepted"
    );

    // Result pointee type must match the DECLARED field type, not whatever
    // sits at that byte offset: pointing field 0's result at u32 (field 1's
    // type) must be rejected even though both are in-bounds indices.
    let op_wrong_result_ty = Operation::new(
        &mut ctx,
        MirFieldAddrOp::get_concrete_op_info(),
        vec![u32_ptr_ty.into()],
        vec![tuple_ptr],
        vec![],
        0,
    );
    let wrong_result_ty = MirFieldAddrOp::new(op_wrong_result_ty);
    wrong_result_ty.set_attr_field_index(&ctx, FieldIndexAttr(0));
    assert!(
        wrong_result_ty.verify(&ctx).is_err(),
        "result pointee type mismatch rejected"
    );

    let op_out_of_bounds = Operation::new(
        &mut ctx,
        MirFieldAddrOp::get_concrete_op_info(),
        vec![u8_ptr_ty.into()],
        vec![tuple_ptr],
        vec![],
        0,
    );
    let out_of_bounds = MirFieldAddrOp::new(op_out_of_bounds);
    out_of_bounds.set_attr_field_index(&ctx, FieldIndexAttr(2));
    assert!(
        out_of_bounds.verify(&ctx).is_err(),
        "out-of-bounds tuple field index rejected"
    );
}

#[test]
fn test_mir_field_addr_tuple_pointee_store_verify() {
    // The WRITE side of the tuple-pointee unlock: `t.1 = x` / `arr[i].1 = x`
    // lower to `mir.field_addr` + `mir.store` through the field's address, so
    // a tuple-pointee field address used as a store destination must pass
    // verification too. Same reordered `(u8, u32)` layout as above (the u32
    // field first in memory), so the store type-checks against the DECLARED
    // field type, not whatever occupies that memory slot.
    let mut ctx = Context::new();
    dialect_mir::register(&mut ctx);

    let u8_ty = IntegerType::get(&ctx, 8, Signedness::Unsigned);
    let u32_ty = IntegerType::get(&ctx, 32, Signedness::Unsigned);

    let tuple_ty = MirTupleType::get_with_layout(
        &mut ctx,
        vec![u8_ty.into(), u32_ty.into()],
        vec![1, 0],
        vec![4, 0],
        8,
        4,
    );

    let tuple_ptr_ty = MirPtrType::get_generic(&mut ctx, tuple_ty.into(), false);
    let blk = BasicBlock::new(
        &mut ctx,
        None,
        vec![tuple_ptr_ty.into(), u32_ty.into(), u8_ty.into()],
    );
    let tuple_ptr = blk.deref(&ctx).get_argument(0);
    let u32_val = blk.deref(&ctx).get_argument(1);
    let u8_val = blk.deref(&ctx).get_argument(2);

    // `.1 = x`: address declaration field 1 (u32, memory slot 0) and store a
    // u32 through it.
    let u32_ptr_ty = MirPtrType::get_generic(&mut ctx, u32_ty.into(), false);
    let op_field1 = Operation::new(
        &mut ctx,
        MirFieldAddrOp::get_concrete_op_info(),
        vec![u32_ptr_ty.into()],
        vec![tuple_ptr],
        vec![],
        0,
    );
    let field1 = MirFieldAddrOp::new(op_field1);
    field1.set_attr_field_index(&ctx, FieldIndexAttr(1));
    assert!(
        field1.verify(&ctx).is_ok(),
        "tuple field 1 (u32) address accepted as a store destination"
    );
    let field1_ptr = op_field1.deref(&ctx).get_result(0);

    let op_store = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![field1_ptr, u32_val],
        vec![],
        0,
    );
    assert!(
        MirStoreOp::new(op_store).verify(&ctx).is_ok(),
        "store through a tuple field address verifies"
    );

    // The stored value must match the DECLARED field type (`u32` for `.1`),
    // not the type of the field sharing the tuple: a u8 store through the
    // `.1` pointer is a type mismatch.
    let op_store_wrong_ty = Operation::new(
        &mut ctx,
        MirStoreOp::get_concrete_op_info(),
        vec![],
        vec![field1_ptr, u8_val],
        vec![],
        0,
    );
    assert!(
        MirStoreOp::new(op_store_wrong_ty).verify(&ctx).is_err(),
        "store of a mismatched value type through a tuple field address rejected"
    );
}
